<?php 
 
 $host_name = 'localhost';
 $db_user = 'root';
 $db_password = '';
 $db_name = 'wdlv2401';

 $db_connect = mysqli_connect($host_name, $db_user, $db_password, $db_name);

?>

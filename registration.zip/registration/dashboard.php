<?php 
  require 'db.php';
  require 'includes/header.php'
 ?>

   <h1>WelCome to Dashboard</h1>

<?php require 'includes/footer.php' ?>